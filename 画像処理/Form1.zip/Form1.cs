﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace 画像処理

// https://dobon.net/vb/dotnet/graphics/createimage.html
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
        //using System.Drawing;

        const int pictureBoxWidth = 1000;
        const int pictureBoxHeight = 750;
        int FinalPictureWidth = 1000;
        int FinalBoxHeight = 750;
        float reSizeRate;
        int[,,] imageRGB = new int[pictureBoxWidth, pictureBoxHeight, 3];

        //描画先とするImageオブジェクトを作成する
        Bitmap canvas = new Bitmap(pictureBoxWidth, pictureBoxHeight);


        private void PreviewDrowPicture()
        {
            //ImageオブジェクトのGraphicsオブジェクトを作成する
            Graphics g = Graphics.FromImage(canvas);

            //画像ファイルを読み込んで、Imageオブジェクトとして取得する
            Image img = Image.FromFile(textBoxFileName.Text);

            //リサイズ率が小さいほう
            reSizeRate = ((float)pictureBox1.Width / (float)img.Width) < ((float)pictureBox1.Height / (float)img.Height) ? (float)pictureBox1.Width / (float)img.Width : (float)pictureBox1.Height / (float)img.Height;

            //画像をcanvasの座標(0, 0)の位置に描画する
            float w = (float)img.Width;
            float h = (float)img.Height;
            g.DrawImage(img, 0, 0, (int)(w* reSizeRate), (int)(h * reSizeRate));
            //Imageオブジェクトのリソースを解放する
            img.Dispose();

            //Graphicsオブジェクトのリソースを解放する
            g.Dispose();

         //   resize_Picture();
            //PictureBox1に表示する
       //     pictureBox1.Height = (int)(h * reSizeRate);
         //   pictureBox1.Width = (int)(w* reSizeRate);
            pictureBox1.Image = canvas;
        }
        private void drowEdgeLine()
        {

        }

        private void Form1_DragDrop(object sender, DragEventArgs e)
        {
            //コントロール内にドロップされたとき実行される
            //ドロップされたすべてのファイル名を取得する
            string[] fileName = (string[])e.Data.GetData(DataFormats.FileDrop, false);
            //ListBoxに追加する
            textBoxFileName.Text = fileName[0];

            PreviewDrowPicture();
        }

        private void Form1_DragEnter(object sender, DragEventArgs e)
        {
            //コントロール内にドラッグされたとき実行される
            if (e.Data.GetDataPresent(DataFormats.FileDrop))
                //ドラッグされたデータ形式を調べ、ファイルのときはコピーとする
                e.Effect = DragDropEffects.Copy;
            else
                //ファイル以外は受け付けない
                e.Effect = DragDropEffects.None;
        }

        private void buttonSave_Click(object sender, EventArgs e)
        {
            int kakuchoshi = textBoxFileName.Text.IndexOf(".");
            string outputFileName = textBoxFileName.Text.Substring(0, kakuchoshi) + ".jpg";

            canvas.Save(outputFileName + "_output_" + ".jpg");

        }

        private void resize_Picture()
        {
            int kakuchoshi = textBoxFileName.Text.IndexOf(".");
            string outputFileName = textBoxFileName.Text.Substring(0, kakuchoshi) + ".jpg";
            //画像ファイルを読み込んで、Imageオブジェクトとして取得する
            Image img = Image.FromFile(textBoxFileName.Text);

            //  Bitmap bmp_YMCK = new Bitmap(textBoxFileName.Text);

            // Bitmap bmp_YMCK = new Bitmap(paperWidth, paperHight);
            //ImageオブジェクトのGraphicsオブジェクトを作成する
            // Graphics g = Graphics.FromImage(bmp_YMCK);

            //リサイズ率が小さいほう    https://www.ipentec.com/document/csharp-resize-image
            // reSizeRate = ((float)FinalPictureWidth / (float)img.Width) < ((float)FinalBoxHeight / (float)img.Height) ? (float)FinalPictureWidth / (float)img.Width : (float)FinalBoxHeight / (float)img.Height;
            FinalPictureWidth = (int)(reSizeRate * (float)img.Width);
            FinalBoxHeight = (int)(reSizeRate * (float)img.Height);
            Bitmap resizeBmp = new Bitmap(FinalPictureWidth, FinalBoxHeight);
            Graphics g = Graphics.FromImage(resizeBmp);
            g.InterpolationMode = System.Drawing.Drawing2D.InterpolationMode.HighQualityBicubic;
            g.DrawImage(img, 0, 0, FinalPictureWidth, FinalBoxHeight);
            Application.DoEvents();

            //    canvas.Save(outputFileName + "_1_" + ".jpg");
            //ImageオブジェクトのGraphicsオブジェクトを作成する
            g = Graphics.FromImage(canvas);
            //PictureBox1に表示する
            pictureBox1.Image = canvas;
            canvas.Dispose();
        }


        private void buttonDrowEdgeLine_Click(object sender, EventArgs e)
        {
            Color c = Color.FromArgb(255, 0, 0);
            for (int x = 0; x < pictureBoxWidth; x++)
            {
                canvas.SetPixel(x, 0, c);
            }
            for (int y = 0; y < pictureBoxHeight; y++)
            {

                canvas.SetPixel(0, y, c);
            }
            for (int x = 0; x < pictureBoxWidth; x++)
            {
                canvas.SetPixel(x, FinalBoxHeight-1, c);
            }
            for (int y = 0; y < pictureBoxHeight; y++)
            {

                canvas.SetPixel(FinalPictureWidth-1, y, c);
            }


            pictureBox1.Image = canvas;
            //            PreviewDrowPicture();
        }
    }
}
